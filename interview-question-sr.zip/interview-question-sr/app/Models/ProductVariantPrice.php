<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductVariantPrice extends Model
{
    public function pvo(){
        return $this->belongsTo(ProductVariant::class,'product_variant_one')->select('id','variant');
    }
    public function pvt(){
        return $this->belongsTo(ProductVariant::class,'product_variant_two')->select('id','variant');
    }
    public function pvth(){
        return $this->belongsTo(ProductVariant::class,'product_variant_three')->select('id','variant');
    }
}
