<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\ProductVariantPrice;
use App\Models\Variant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Http\Response|\Illuminate\View\View
     */
    public function index(Request $request)
    {

        $variant=Variant::with('product_variant')->get();
        $products=Product::with('variant_product_price')->paginate(1);
        return view('products.index',compact('products','variant'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Http\Response|\Illuminate\View\View
     */
    public function create()
    {
        $variants = Variant::all();
        return view('products.create', compact('variants'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(Request $request)
    {

        $product = new Product;
        $product->title=$request['title'];
        $product->sku=$request['sku'] ?? "";
        $product->description=$request['description'] ?? "";
        $product->save();
        $varients= $request->product_variant;
        foreach($varients as $variant){
            $tags=$variant['tags'];
            foreach($tags as $tag){
               $product_variant= new ProductVariant;
               $product_variant->product_id=$product->id;
               $product_variant->variant_id=$variant['option'];
               $product_variant->variant=$tag;
               $product_variant->save();
            }
        }
        $pro_var_price = $request['product_variant_prices'];
        foreach($pro_var_price as $value){
        $str = explode('/', $value['title']);
        $items = ProductVariant::whereIn('variant', $str)->select('id')->get();
        $pro1= $items[0]['id'] ?? null;
        $pro2= $items[1]['id'] ?? null;
        $pro3=$items[2]['id'] ?? null;
        $pvp=new ProductVariantPrice;
        $pvp->product_variant_one=$pro1;
        $pvp->product_variant_two=$pro2;
        $pvp->product_variant_three=$pro3;
        $pvp->price=$value['price'];
        $pvp->stock=$value['stock'];
        $pvp->product_id=$product->id;
        $pvp->save();
        }
    }


    /**
     * Display the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function show($product)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        $variants = Variant::all();
        return view('products.edit', compact('variants'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
    //ProductSearch
    public function ProductSearch(Request $request){
        return $product=Product::where('title','like','%'.$request['title'].'%')->select('id','title','description')->get();
    }
}
